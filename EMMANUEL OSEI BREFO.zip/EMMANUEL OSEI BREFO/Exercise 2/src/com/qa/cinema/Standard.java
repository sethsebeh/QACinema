package com.qa.cinema;

/** 
 * @author EMMANUEL OSEI-BREFO
 */
public class Standard extends Ticket{

    public Standard() {
        super("Standard" , 8);
    }
        
}
