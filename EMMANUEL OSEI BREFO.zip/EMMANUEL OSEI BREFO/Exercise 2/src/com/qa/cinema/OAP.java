package com.qa.cinema;

/** 
 * @author EMMANUEL OSEI-BREFO
 */
public class OAP extends Ticket{

    public OAP() {
        super("OAP" , 6);
    }
        
}
