package com.qa.cinema;

/** 
 * @author EMMANUEL OSEI-BREFO
 */
public class Child extends Ticket{

    public Child() {
        super("Child" , 6);
    }
        
}
