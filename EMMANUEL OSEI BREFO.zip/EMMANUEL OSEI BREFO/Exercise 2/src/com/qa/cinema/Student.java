package com.qa.cinema;

/** 
 * @author EMMANUEL OSEI-BREFO
 */
public class Student extends Ticket{

    public Student() {
        super("Student" , 6);
    }
        
}
