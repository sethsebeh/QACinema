package com.qa.cinema;

/** 
 * @author EMMANUEL OSEI-BREFO
 */
public class Discount{
    private float discount;

    public float getDiscount() {
        return discount;
    }

    public void setDiscount(float discount) {
        this.discount = discount;
    }
        
}
